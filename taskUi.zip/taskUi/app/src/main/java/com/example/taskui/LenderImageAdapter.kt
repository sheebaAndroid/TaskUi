package com.example.taskui

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.taskui.databinding.LayoutFollowerListBinding

class LenderImageAdapter( private val context: Context,):
RecyclerView.Adapter<LenderImageAdapter.ViewHolder>() {
    var imageList: List<Drawable?> = emptyList()
    fun submitList(projectList: List<Drawable?>){
        imageList=projectList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutFollowerListBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position,context,imageList)
    }

    override fun getItemCount(): Int = imageList.size

    class ViewHolder(private val itemLayoutImage: LayoutFollowerListBinding) :
        RecyclerView.ViewHolder(itemLayoutImage.root) {

        fun bind(
            position: Int,
          context:Context,
            imageList: List<Drawable?>,

        ) {
            itemLayoutImage.imageLender.setImageDrawable(imageList[position])


        }
    }
}