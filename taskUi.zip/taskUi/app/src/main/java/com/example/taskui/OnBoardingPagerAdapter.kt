package com.example.taskui

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import com.example.taskui.databinding.LayoutOnBoardingBinding

class OnBoardingPagerAdapter(
    private val context: Context,
    private val onBoardingImagesList: List<Drawable?>,
) : PagerAdapter() {

    override fun getCount(): Int = onBoardingImagesList.size

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view == `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val binding =
            LayoutOnBoardingBinding.inflate(LayoutInflater.from(context), container, false)
        binding.ivOnBoarding.setImageDrawable(onBoardingImagesList[position])

        container.addView(binding.root)
        return binding.root
    }

    override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
        collection.removeView(view as View)
    }
}