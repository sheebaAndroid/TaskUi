package com.example.taskui

import android.content.Context
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.taskui.databinding.AdapterHistoryBinding
import java.net.URL


class HistoryAdapter(var context: Context) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    var stakeAsset: ArrayList<HistoryList> = arrayListOf()

    fun onSubmitList(list: ArrayList<HistoryList>) {
        this.stakeAsset = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            DataBindingUtil.inflate(
                LayoutInflater.from(context),
                R.layout.adapter_history,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.apply {
            /*val url = URL(stakeAsset[position].user_icon)
            val bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream())
            imgBgLogo.setImageBitmap(bmp)*/
            textName.text = stakeAsset[position].user_name
            textAmount.text = stakeAsset[position].amount
            textTime.text = stakeAsset[position].time
            textBankName.text = stakeAsset[position].bank_name
            txtSts.text = stakeAsset[position].status

            if (stakeAsset[position].status == "Completed") {
                imgSts.background = ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_accepted
                )
            }else{
                imgSts.background = ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_rejected
                )
            }


            /*Glide.with(context).load(stakeAsset[position].user_icon)
                .placeholder(R.drawable.img_profile)
                .error(R.drawable.img_profile)
                .into(imgBgLogo)*/
//            imgBgLogo.setImageUrl(stakeAsset[position].image)
        }
    }

    override fun getItemCount(): Int {
        return stakeAsset.size
    }

    class ViewHolder(val binding: AdapterHistoryBinding) :
        RecyclerView.ViewHolder(binding.root)

}