package com.example.taskui

import android.content.Context
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.example.taskui.databinding.ActivityMainBinding
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var adapterLenderImageAdapter: LenderImageAdapter? = null
    private var historyAdapter: HistoryAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        config()
    }

    fun config() {
        val onBoardingImagesList = arrayListOf<Drawable?>()
        onBoardingImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.bg_rounded
            )
        )
        onBoardingImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.bg_rounded
            )
        )
        onBoardingImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.bg_rounded
            )
        )
        val onBoardingPagerAdapter = OnBoardingPagerAdapter(this, onBoardingImagesList)
        binding.vpOnBoarding.adapter = onBoardingPagerAdapter
        onBoardingPagerAdapter.notifyDataSetChanged()
//        binding.vpOnBoarding.setPageTransformer(false, onBoardingPagerAdapter)

        binding.vpOnBoarding.offscreenPageLimit = onBoardingImagesList.size
        binding.vpOnBoarding.clipToPadding = false
        binding.diOnBoarding.setViewPager(binding.vpOnBoarding)
        val profileImagesList = arrayListOf<Drawable?>()
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )
        profileImagesList.add(
            ContextCompat.getDrawable(
                this,
                R.drawable.ic_profileimg
            )
        )

        adapterLenderImageAdapter = LenderImageAdapter(this)
        binding.followersImageRecyclerView.adapter = adapterLenderImageAdapter
        binding.followersImageRecyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        if (profileImagesList.isNullOrEmpty().not()) {
            adapterLenderImageAdapter?.submitList(profileImagesList)
        }

        val historyArray = arrayListOf<HistoryList>()

        historyArray.add(
            HistoryList(
                id = 1,
                user_icon = "https://res.cloudinary.com/dzklqz4hm/image/upload/v1722610904/Marcus_klt5bd.png",
                user_name = "Marcus Gouse",
                time = "10:51 PM",
                status = "Completed",
                bank_name = "Bank 1",
                amount = "20,000.00",
                bank_id = "",
                user_id = "",
                type = "Completed"
            )
        )
        historyArray.add(
            HistoryList(
                id = 2,
                user_icon = "https://res.cloudinary.com/dzklqz4hm/image/upload/v1722610905/Nike_y0niz1.png",
                user_name = "Nike",
                time = "10:51 PM",
                status = "Failed",
                bank_name = "Bank 2",
                amount = "9.00",
                bank_id = "",
                user_id = "",
                type = "Failed"
            )
        )
        historyArray.add(
            HistoryList(
                id = 3,
                user_icon = "https://res.cloudinary.com/dzklqz4hm/image/upload/v1722610905/Roger_wop2uz.png",
                user_name = "Roger Carder",
                time = "10:51 PM",
                status = "Completed",
                bank_name = "Bank 1",
                amount = "9.00",
                bank_id = "",
                user_id = "",
                type = "Completed"
            )
        )
        historyArray.add(
            HistoryList(
                id = 4,
                user_icon = "https://res.cloudinary.com/dzklqz4hm/image/upload/v1722610904/Brandon_q23pim.png",
                user_name = "Brandon",
                time = "10:51 PM",
                status = "Completed",
                bank_name = "Bank 2",
                amount = "20,000.00",
                bank_id = "",
                user_id = "",
                type = "Completed"
            )
        )
        historyArray.add(
            HistoryList(
                id = 5,
                user_icon = "https://res.cloudinary.com/dzklqz4hm/image/upload/v1721042438/Group_1321315034_iml6he.png",
                user_name = "Roger Carder",
                time = "10:51 PM",
                status = "Completed",
                bank_name = "Bank 1",
                amount = "20,000.00",
                bank_id = "",
                user_id = "",
                type = "Completed"
            )
        )

        historyAdapter = HistoryAdapter(this)
        binding.rvList.adapter = historyAdapter
        binding.rvList.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        if (historyArray.isNullOrEmpty().not()) {
            historyAdapter?.onSubmitList(historyArray)
        }


//        handler = Handler(Looper.getMainLooper())
        var currentOnBoardingPage = 0
//        runnable = Runnable {
//            if (currentOnBoardingPage == binding.vpOnBoarding.adapter?.count) {
//                currentOnBoardingPage = 0
//            }
//            binding.vpOnBoarding.setCurrentItem(currentOnBoardingPage++, true)
//        }
//        val timer = Timer()
//        timer.schedule(object : TimerTask() {
//            // task to be scheduled
//            override fun run() {
//                handler.post(runnable)
//            }
//        }, TAG.DELAY_MS, TAG.PERIOD_MS)
        binding.vpOnBoarding.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {

            }

            override fun onPageSelected(position: Int) {
                currentOnBoardingPage = position
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
        Handler(Looper.getMainLooper()).post {
            if (binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem - 1) != null) {
                binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem - 1).scaleX = 0.8F
                binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem - 1).scaleY = 0.8F
            }
            if (binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem + 1) != null) {
                binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem + 1).scaleX = 0.8F
                binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem + 1).scaleY = 0.8F
            }
            if (binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem) != null) {
                binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem).scaleX = 1F
                binding.vpOnBoarding.getChildAt(binding.vpOnBoarding.currentItem).scaleY = 1F
            }
        }
    }


}

data class HistoryList(

    val id: Long,
    val user_id: String,
    val user_name: String,
    val user_icon: String,
    val bank_id: String?,
    val bank_name: String,
    val status: String,
    val time: String,
    val amount: String,
    val type: String?,

    )